import Contacto from "./Contacto";

export default function Page() {
  return <Contacto />;
}