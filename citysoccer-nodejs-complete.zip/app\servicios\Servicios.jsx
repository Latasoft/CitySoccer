'use client';
export default function Servicios() {
  return (
    <div>
      <h1>Servicios</h1>
      <p>Estos son los servicios que ofrecemos:</p>
      <ul>
        <li>Arriendo de canchas</li>
        <li>Clases de fútbol</li>
        <li>Clases de pickleball</li>
      </ul>
    </div>
  );
}
