'use client';

import React, { useState } from "react"; 

export default function Arrendarcancha() {
    return (
        <div>
            <h1>Arrendar Cancha</h1>
        </div>
    );
}