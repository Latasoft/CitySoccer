import Servicios from "./Servicios";

export default function Page() {
  return <Servicios />;
}