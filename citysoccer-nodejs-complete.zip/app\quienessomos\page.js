import Quienessosmos from "./Quienessomos";

export default function Page() {
  return <Quienessosmos />;
}