import { dynamicConfigService } from '@/lib/dynamicConfigService';

// Función para obtener precios dinámicos
export const getPricesData = async () => {
  try {
    const dynamicPrices = await dynamicConfigService.getPrices();
    return dynamicPrices;
  } catch (error) {
    console.error('Error obteniendo precios dinámicos, usando fallback:', error);
    return getFallbackPricesData();
  }
};

// Precios por defecto como fallback
function getFallbackPricesData() {
  return {
    futbol7: {
      name: "Fútbol 7",
      schedule: {
        weekdays: {
          "9:00": { price: 30000 },
          "10:00": { price: 30000 },
          "11:00": { price: 30000 },
          "12:00": { price: 30000 },
          "13:00": { price: 30000 },
          "14:00": { price: 30000 },
          "15:00": { price: 30000 },
          "16:00": { price: 30000 },
          "17:00": { price: 45000 },
          "18:00": { price: 50000 },
          "19:00": { price: 50000 },
          "20:00": { price: 50000 },
          "21:00": { price: 50000 },
          "22:00": { price: 50000 },
          "23:00": { price: 45000 }
        },
        saturday: {
          "9:00": { price: 30000 },
          "10:00": { price: 30000 },
          "11:00": { price: 30000 },
          "12:00": { price: 30000 },
          "13:00": { price: 30000 },
          "14:00": { price: 30000 },
          "15:00": { price: 30000 },
          "16:00": { price: 30000 },
          "17:00": { price: 45000 },
          "18:00": { price: 50000 },
          "19:00": { price: 50000 },
          "20:00": { price: 50000 },
          "21:00": { price: 50000 },
          "22:00": { price: 50000 },
          "23:00": { price: 45000 }
        },
        sunday: {
          "9:00": { price: 30000 },
          "10:00": { price: 30000 },
          "11:00": { price: 30000 },
          "12:00": { price: 30000 },
          "13:00": { price: 30000 },
          "14:00": { price: 30000 },
          "15:00": { price: 30000 },
          "16:00": { price: 30000 },
          "17:00": { price: 45000 },
          "18:00": { price: 50000 },
          "19:00": { price: 50000 },
          "20:00": { price: 50000 },
          "21:00": { price: 50000 },
          "22:00": { price: 50000 },
          "23:00": { price: 45000 }
        }
      },
      equipment: {
        rent_ball: { name: "Arriendo de Balón N4 y N5", price: 5000 },
        sell_ball: { name: "Venta de Balón N4 y N5", price: 20000 }
      }
    },
    futbol9: {
      name: "Fútbol 9",
      schedule: {
        weekdays: {
          "06:00": { price: 45000 },
          "07:00": { price: 45000 },
          "08:00": { price: 45000 },
          "09:00": { price: 65000 },
          "10:00": { price: 65000 },
          "11:00": { price: 65000 },
          "12:00": { price: 65000 },
          "13:00": { price: 65000 },
          "14:00": { price: 65000 },
          "15:00": { price: 65000 },
          "16:00": { price: 65000 },
          "17:00": { price: 75000 },
          "18:00": { price: 90000 },
          "19:00": { price: 90000 },
          "20:00": { price: 90000 },
          "21:00": { price: 90000 },
          "22:00": { price: 90000 },
          "23:00": { price: 75000 }
        },
        saturday: {
          "06:00": { price: 55000 },
          "09:00": { price: 65000 },
          "10:00": { price: 65000 },
          "11:00": { price: 65000 },
          "12:00": { price: 65000 },
          "13:00": { price: 65000 },
          "14:00": { price: 65000 },
          "15:00": { price: 65000 },
          "16:00": { price: 65000 },
          "17:00": { price: 75000 },
          "18:00": { price: 90000 },
          "19:00": { price: 90000 },
          "20:00": { price: 90000 },
          "21:00": { price: 90000 },
          "22:00": { price: 90000 },
          "23:00": { price: 75000 }
        },
        sunday: {
          "06:00": { price: 65000 },
          "09:00": { price: 65000 },
          "10:00": { price: 65000 },
          "11:00": { price: 65000 },
          "12:00": { price: 65000 },
          "13:00": { price: 65000 },
          "14:00": { price: 65000 },
          "15:00": { price: 65000 },
          "16:00": { price: 65000 },
          "17:00": { price: 75000 },
          "18:00": { price: 90000 },
          "19:00": { price: 90000 },
          "20:00": { price: 90000 },
          "21:00": { price: 90000 },
          "22:00": { price: 90000 },
          "23:00": { price: 75000 }
        }
      },
      equipment: {
        ball: { name: "Balón de Fútbol", price: 5000 },
        vest: { name: "Petos (juego completo)", price: 8000 }
      }
    },
    pickleball: {
      name: "Pickleball",
      schedule: {
        weekdays: {
          "06:00": { price: 15000 },
          "07:00": { price: 15000 },
          "08:00": { price: 15000 },
          "09:00": { price: 15000 },
          "10:00": { price: 15000 },
          "11:00": { price: 15000 },
          "12:00": { price: 15000 },
          "13:00": { price: 15000 },
          "14:00": { price: 15000 },
          "15:00": { price: 15000 },
          "16:00": { price: 15000 },
          "17:00": { price: 15000 },
          "18:00": { price: 15000 },
          "19:00": { price: 15000 },
          "20:00": { price: 15000 },
          "21:00": { price: 15000 },
          "22:00": { price: 15000 },
          "23:00": { price: 15000 }
        },
        saturday: {
          "06:00": { price: 20000 },
          "09:00": { price: 15000 },
          "10:00": { price: 15000 },
          "11:00": { price: 15000 },
          "12:00": { price: 15000 },
          "13:00": { price: 15000 },
          "14:00": { price: 15000 },
          "15:00": { price: 15000 },
          "16:00": { price: 15000 },
          "17:00": { price: 15000 },
          "18:00": { price: 15000 },
          "19:00": { price: 15000 },
          "20:00": { price: 15000 },
          "21:00": { price: 15000 },
          "22:00": { price: 15000 },
          "23:00": { price: 15000 }
        },
        sunday: {
          "06:00": { price: 25000 },
          "09:00": { price: 15000 },
          "10:00": { price: 15000 },
          "11:00": { price: 15000 },
          "12:00": { price: 15000 },
          "13:00": { price: 15000 },
          "14:00": { price: 15000 },
          "15:00": { price: 15000 },
          "16:00": { price: 15000 },
          "17:00": { price: 15000 },
          "18:00": { price: 15000 },
          "19:00": { price: 15000 },
          "20:00": { price: 15000 },
          "21:00": { price: 15000 },
          "22:00": { price: 15000 },
          "23:00": { price: 15000 }
        }
      }
    }
  };
}

// Exportar también la estructura estática para compatibilidad
export const pricesData = getFallbackPricesData();
