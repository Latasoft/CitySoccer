'use client';
import React from "react"; 
import QuienessomosComponent from "@/components/QuienessomosComponent"; // Asegúrate de que la ruta sea correcta
export default function QuienessomosPage() {
    return (
      <div>
        {/* Tu contenido aquí */}
        <QuienessomosComponent /> {/* Asegúrate de que este componente esté definido o importado */}
      </div>
    );
}